<?php
// Database Configuration Template
// Copy this file to database.php and update with your actual credentials

return [
    'host' => 'localhost',
    'database' => 'yourusername_elite_car_hire',  // Your cPanel database name (with prefix)
    'username' => 'yourusername_eliteadmin',      // Your cPanel database user (with prefix)
    'password' => 'YOUR_DATABASE_PASSWORD',       // Your database password from Step 3
    'charset' => 'utf8mb4',
];
