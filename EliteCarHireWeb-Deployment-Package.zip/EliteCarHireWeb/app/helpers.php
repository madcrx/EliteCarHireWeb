<?php
// Helper Functions

function config($key, $default = null) {
    static $config = null;
    if ($config === null) {
        $config = require __DIR__ . '/../config/app.php';
    }
    
    $keys = explode('.', $key);
    $value = $config;
    
    foreach ($keys as $k) {
        if (!isset($value[$k])) {
            return $default;
        }
        $value = $value[$k];
    }
    
    return $value;
}

function db() {
    return Database::getInstance();
}

function redirect($path) {
    header("Location: $path");
    exit;
}

function view($name, $data = []) {
    extract($data);
    require __DIR__ . "/views/$name.php";
}

function auth() {
    return isset($_SESSION['user_id']) ? $_SESSION : null;
}

function authUser() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    $sql = "SELECT * FROM users WHERE id = ?";
    return db()->fetch($sql, [$_SESSION['user_id']]);
}

function requireAuth($role = null) {
    if (!auth()) {
        redirect('/login');
    }
    
    if ($role && $_SESSION['role'] !== $role) {
        redirect('/login');
    }
}

function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function csrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verifyCsrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function flash($key, $value = null) {
    if ($value === null) {
        $msg = $_SESSION["flash_$key"] ?? null;
        unset($_SESSION["flash_$key"]);
        return $msg;
    }
    $_SESSION["flash_$key"] = $value;
}

function old($key, $default = '') {
    return $_SESSION['old'][$key] ?? $default;
}

function setOld($data) {
    $_SESSION['old'] = $data;
}

function clearOld() {
    unset($_SESSION['old']);
}

function generateBookingReference() {
    return 'ECH' . date('Ymd') . strtoupper(substr(md5(uniqid(rand(), true)), 0, 6));
}

function formatMoney($amount) {
    return '$' . number_format($amount, 2);
}

function sendEmail($to, $subject, $body) {
    $headers = "From: " . config('email.from_name') . " <" . config('email.from_address') . ">\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    
    // Queue email for sending
    $sql = "INSERT INTO email_queue (to_email, to_name, subject, body_html, status) VALUES (?, ?, ?, ?, 'pending')";
    try {
        db()->execute($sql, [$to, '', $subject, $body]);
        return true;
    } catch (Exception $e) {
        error_log("Failed to queue email: " . $e->getMessage());
        return false;
    }
}

function logAudit($action, $entityType = null, $entityId = null, $oldValues = null, $newValues = null) {
    $userId = $_SESSION['user_id'] ?? null;
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    $sql = "INSERT INTO audit_logs (user_id, action, entity_type, entity_id, ip_address, user_agent, old_values, new_values) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    db()->execute($sql, [
        $userId,
        $action,
        $entityType,
        $entityId,
        $ipAddress,
        $userAgent,
        $oldValues ? json_encode($oldValues) : null,
        $newValues ? json_encode($newValues) : null
    ]);
}

function createNotification($userId, $type, $title, $message, $link = null) {
    $sql = "INSERT INTO notifications (user_id, type, title, message, link) VALUES (?, ?, ?, ?, ?)";
    db()->execute($sql, [$userId, $type, $title, $message, $link]);
}

function asset($path) {
    return '/assets/' . ltrim($path, '/');
}

function url($path = '') {
    return rtrim(config('app.url'), '/') . '/' . ltrim($path, '/');
}

function json($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function uploadFile($file, $directory = 'uploads') {
    if (!isset($file['error']) || $file['error'] !== UPLOAD_ERR_OK) {
        return false;
    }
    
    $maxSize = config('upload.max_file_size');
    if ($file['size'] > $maxSize) {
        return false;
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $allowedTypes = config('upload.allowed_types');
    
    if (!in_array(strtolower($extension), $allowedTypes)) {
        return false;
    }
    
    $filename = uniqid() . '_' . time() . '.' . $extension;
    $destination = __DIR__ . "/../storage/$directory/" . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $destination)) {
        return "storage/$directory/$filename";
    }
    
    return false;
}
