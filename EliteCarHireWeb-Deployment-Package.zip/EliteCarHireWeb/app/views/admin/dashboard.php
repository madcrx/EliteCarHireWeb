<?php ob_start(); ?>
<div class="sidebar-layout">
    <?php include 'sidebar.php'; ?>
    <div class="main-content">
        <div class="dashboard-header">
            <h1>Admin Dashboard</h1>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?= $stats['total_users'] ?></h3>
                <p>Total Users</p>
            </div>
            <div class="stat-card">
                <h3><?= $stats['pending_users'] ?></h3>
                <p>Pending Approvals</p>
            </div>
            <div class="stat-card">
                <h3><?= $stats['total_vehicles'] ?></h3>
                <p>Total Vehicles</p>
            </div>
            <div class="stat-card">
                <h3><?= formatMoney($stats['total_revenue']) ?></h3>
                <p>Monthly Revenue</p>
            </div>
        </div>

        <div class="card" style="background: linear-gradient(135deg, var(--primary-gold) 0%, #a88a3d 100%); color: white;">
            <h2 style="color: white; margin-bottom: 1rem;"><i class="fas fa-images"></i> Image Management</h2>
            <p style="margin-bottom: 1.5rem;">Manage website images, logos, and banners. Upload new images or revert to defaults.</p>
            <a href="/admin/images" class="btn" style="background: white; color: var(--primary-gold); padding: 10px 20px; text-decoration: none; display: inline-block; border-radius: var(--border-radius); font-weight: bold;">
                Manage Images
            </a>
        </div>

        <div class="card">
            <h2>Recent Bookings</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Customer</th>
                            <th>Vehicle</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentBookings as $booking): ?>
                            <tr>
                                <td><?= e($booking['booking_reference']) ?></td>
                                <td><?= e($booking['first_name'] . ' ' . $booking['last_name']) ?></td>
                                <td><?= e($booking['make'] . ' ' . $booking['model']) ?></td>
                                <td><?= date('M d, Y', strtotime($booking['booking_date'])) ?></td>
                                <td><?= formatMoney($booking['total_amount']) ?></td>
                                <td><span class="badge badge-<?= $booking['status'] === 'completed' ? 'success' : 'warning' ?>"><?= ucfirst($booking['status']) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <?php if (!empty($recentUsers)): ?>
        <div class="card">
            <h2>Pending User Approvals</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Registered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentUsers as $user): ?>
                            <tr>
                                <td><?= e($user['first_name'] . ' ' . $user['last_name']) ?></td>
                                <td><?= e($user['email']) ?></td>
                                <td><?= ucfirst($user['role']) ?></td>
                                <td><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                                <td>
                                    <form method="POST" action="/admin/users/<?= $user['id'] ?>/approve" style="display: inline;">
                                        <button class="btn btn-primary" style="padding: 5px 15px;">Approve</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $content = ob_get_clean(); include __DIR__ . '/../layout.php'; ?>
